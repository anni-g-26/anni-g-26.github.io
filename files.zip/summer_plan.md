# 6-Week Summer Plan — Poli Sci / Econ / Business / Writing Track

**Time budget:** ~10-15 hrs/week
**Goal:** Leave summer with a research writing sample, a volunteering/leadership record, a completed course/cert, and something concrete to point to in scholarship essays.

---

## College & Scholarship Research (ongoing, ~1 hr/week)

Since this is rolling into junior year — the year that actually matters most for college applications — worth starting this list now rather than scrambling senior fall.

- **Build a running college list** (spreadsheet: name, location, poli sci/econ/business program strength, rough cost, any early scholarship notes). Start broad (15-20 schools), you'll narrow senior year.
- **Scholarship search, ongoing not one-time:** set up profiles on Bold.org, Fastweb, and your school counselor's scholarship list (many are local/regional and less competitive than national ones). Bookmark any with junior-year-friendly or rolling deadlines.
- **Track application requirements early:** many competitive scholarships want an essay, a resume/activity list, and sometimes a recommendation letter. Your Week 6 "brag sheet" (see below) becomes the raw material for all of these.
- **Target competitions with real deadlines this year:** John Locke Institute Essay Competition and Concord Review both have specific submission windows — check current deadlines directly on their sites since they shift year to year, and calendar them now so they don't sneak up senior year.

---

## Your Research Topic: Trade/Tariff Policy & Consumer Retail Importers

**Working question:** How do tariff announcements and rulings affect stock prices for retail importers?

This is a strong choice because it merges your policy research directly with your stocks learning — you're not just reading about tariffs, you're tracking their real effect on specific companies over the summer, and 2026 has been an unusually active year for this (Supreme Court striking down IEEPA tariffs in February, a Court of International Trade ruling in May, ongoing Section 232 and Section 301 reviews).

**Companies to track (pick 4 — 2 "exposed," 2 "advantaged" for contrast):**
- Exposed/import-heavy: Target, Best Buy, Nike
- Potential refund beneficiaries / relative winners: Nintendo, Duluth Trading Company, Acushnet Holdings, Insteel Industries, Lifetime Brands

Suggested approach:

- Track your 4 chosen companies' stock price against tariff-related news over the weeks (a simple spreadsheet works fine).
- Read up on the underlying economics: who actually pays a tariff, how markets price in policy expectations, winners vs. losers.
- Your final research piece explains *why* the market reacted the way it did — this is much more original than a generic "are tariffs good or bad" essay.
- Your current-events pieces throughout the summer can track this in real time as news breaks — genuinely useful practice since tariff policy is actively evolving right now.

---

## The Core Idea

Pick **one real-world local or national issue** at the intersection of economics and policy that genuinely interests you (housing costs, minimum wage, small business regulation, local election turnout — whatever grabs you). Everything below builds around it, so your research feeds your writing, and your writing fills out your website. Scholarship committees love a narrative thread, not disconnected bullet points.

Alongside that, you're running two standing habits every week: **learning** (courses) and **current events writing** (short, frequent pieces — separate from your one big research paper).

**Quick clarification on scope:** your *one big research paper* is specifically about tariff policy's impact on retail/consumer importers — that's the deep, polished piece. Your *weekly current-events pieces* are looser — general econ/politics practice writing, not strictly tariffs-only. Since tariffs are so active right now, most weeks will probably end up tariff-related anyway just because that's what's in the news and what you're already tracking, but if something else catches your eye, write about that instead. The habit matters more than staying on one topic every week.

---

## Week 1 — Foundation

- **Pick your issue/question.** Spend a few hours reading news + one or two academic sources. Narrow to a specific, arguable question (not "the economy" — more like "should [your city] adopt rent stabilization?").
- **Set up your website.** Options: GitHub Pages (free, and gives you a coding angle to mention), Carrd, or Squarespace/WordPress if you want more design control. Set up an About page, a clean homepage, and a section for your writing.
- **Enroll in your courses** (Khan Academy is genuinely great here and self-paced):
  - Khan Academy AP Micro/Macroeconomics (direct head start for Honors Gov & Econ)
  - Khan Academy "Stocks and Bonds" / "Investment and Retirement" unit under Personal Finance — solid, free intro to how markets actually work
  - Optional stretch: Wharton Business Foundations Specialization (Coursera) if you want a business-school-style credential too
- **Start a research log** — a doc where you dump sources, quotes, and reactions as you go. This becomes your paper's first draft material.
- **Start your current events habit:** pick one day a week to write a short (300-500 word) reaction to a news story in econ/politics/markets. This is low-pressure practice, not your big essay.

---

## Weeks 2-4 — Build

- **~4-5 hrs/week: Research + writing.** Aim for a polished 1,500-2,500 word policy essay or research paper by end of week 5, plus your ongoing current events pieces.
- **~2-3 hrs/week: Website.** Publish pieces as you finish them — a site with a visible archive of posts over weeks looks more like sustained work than a last-minute upload. The site's identity: a weekly explainer publication debunking confusing econ/political topics in plain language, with your tariffs/retail research as one recurring thread within it (not the whole site). Polish design, add an About/bio section.
- **~2-3 hrs/week: Courses.** Steady progress on your econ and stocks/investing courses.
- **~1-2 hrs/week: Current events writing.** Keep the weekly habit going — by week 4 you'll have 3-4 short pieces alongside your main research.
- **Optional stocks angle:** once you've got the basics down, consider tracking a small hypothetical portfolio (no real money needed) and writing a monthly post on what you're seeing and why — this is a genuinely distinctive thing to show a scholarship committee.

---

## Week 5 — Sharpen

- Finish and revise your main research piece. Get one adult (teacher, parent) to review it.
- Have 6-9 pieces published on your site by this point (research piece + current events + any stocks posts).
- Finish or nearly finish your courses — add both to your site's About page.

---

## Week 6 — Package It

- **Write it all down.** Draft a "brag sheet" — one document listing project, role, hours, and impact for each activity. This is what makes essay-writing in fall painless.
- **Consider submitting your work.** A few realistic, strong targets for this profile:
  - **John Locke Institute Essay Competition** (poli sci/econ/PPE categories — rolling deadlines, prestigious)
  - **Diamond Challenge** (business plan competition for high schoolers)
  - **National Economics Challenge** or **The Concord Review** (research paper publication)
- **Draft one scholarship essay now**, even before you need it — you'll have specific material and it'll be easier to adapt later than to write cold in October.

---

## Tying This to Your Honors Courses (Gov & Econ, Writing/Rhetoric, History/Theology, Biology)

- **Honors Government & Economics:** Your research question, Khan Academy econ course, and weekly current events writing all directly prep you — you'll walk in already fluent in the terms and debates most classmates are seeing cold.
- **Honors Writing/Rhetoric:** Your essay and weekly current events pieces double as rhetoric practice. Worth deliberately trying a few different modes (persuasive op-ed vs. neutral analysis) so you walk in with range.
- **Honors History/Theology:** If your issue has historical roots, spend some time on that background — it deepens your essay and gives you a running start in fall.
- **Honors Biology:** No natural overlap here, and that's fine — don't force a connection.

## Why This Works for Scholarships

Committees are looking for: initiative (you built this yourself, from scratch), depth (one real thread, sustained over weeks, not five shallow ones), and evidence of independent thinking. A polished personal website with a real body of writing, backed by a completed course and ideally a competition submission, gives you all three plus a tangible writing sample and a credential — while staying realistic at 10-15 hrs/week.
